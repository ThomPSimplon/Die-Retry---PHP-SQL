<!DOCTYPE html>
<html>
<head>
	<title>Projet Simplon Games</title>
	<meta charset="utf-8">
	<!--===== CSS =====-->
	<link rel="stylesheet" type="text/css" href="style.css">
	<!--===== CSS END =====-->

	<!--===== FontAwesome =====-->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
	<!--===== FontAwesome END =====-->

	<!--===== Bootstrap: CSS Only =====-->
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!--===== Bootstrap: CSS Only END =====-->

	<!--===== Bootstrap: JS, Popper.js, and jQuery =====-->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
	<!--===== Bootstrap: JS, Popper.js, and jQuery END =====-->
	

<?php 
// Connexion à la Base de donnée à la page php
	try{
	$bdd = new PDO('mysql:host=localhost;dbname=videogames;charset=utf8', 'root', '');
	} catch(PDOException $e){
		die('Erreur : La connexion à la base de donnée a échouée.'. ' ' .$e->getMessage());
	}
?>	

</head>

<body>
	<header id="top" class="container-fluid">
		<div class="row">
		<div class="col-sm-12" align="center">
			<img src="img/title.png" alt="logo die and retry">
		</div>

		<div id="titleheader" class="col-sm-12">
			<h1><strong>DIE & RETRY</strong></h1>
			<p>Gestion d'une collection de jeux vidéo associative</p>
		</div>
		</div>
	</header>

<!-- ===== Boutons AJOUTER/MODIFIER/SUPPRIMER (Pas encore fonctionnelle !)=====-->

	<div class="modifications mt-3 mb-2" align="center">
		<button class="ajout">Ajouter</button>
		<button class="modif">Modifier</button>
		<button class="supp">Supprimer</button>
	</div>


<!-- ===== BARRE DE RECHERCHE (Retourne uniquement les titres recherchés)=====-->

			<form align="center" action="" method="GET">
                <input id="search" type="search" name="search" placeholder="Search a Title..." >
                <input id="button" type="submit" value="Search">
        	</form>


<!-- Tentative de faire fonctionner l'ajout d'un élément dans la BDD (échec: ne s'affiche pas dans le tableau) -->
        	<?php
        	$_POST['Title'] = null;
        	$_POST['ReleaseDate'] = null;
        	if (isset($_POST['Title']) AND isset($_POST['ReleaseDate'])) {
        		$requete = $bdd->prepare(
        			"INSERT INTO videogames(Title, ReleaseDate)
        			 VALUES(?, ?)
        			 SELECT Title, ReleaseDate
        			 FROM videogames");
        		$requete->execute([$_POST['Title'], $_POST['ReleaseDate']]);
        	}
        	?>


        	<form method="POST">
        		<label>Ajouter un titre :</label>
        		<input type="text" name="Title" placeholder="Titre">
        		<input type="text" name="ReleaseDate" placeholder="Date de sortie">
        		<input type="submit" name="Ajouter" class="btn btn-success" value="Ajouter">
        	</form>


			
<!-- ===== Tableau qui va contenir les éléments de la BDD ===== -->
	<content class="container">

		<table align="center">
			<tr align="center">
				<td><b>ID</b></td>
				<td><b>TITLE</b></td>
				<td class="release"><b>RELEASE</b></td>
				<td><b>PLATEFORM</b></td>
				<td class="publishers"><b>PUBLISHED BY</b></td>
				<td class="developers"><b>DEVELOPED BY</b></td>
			</tr>	

<!-- ===== Requêtes pour récupérer des éléments précis de la BDD ===== -->
<?php
	$videog = $bdd->query('SELECT *
		FROM developers INNER JOIN videogames ON developers.id=videogames.idDeveloper
		ORDER BY videogames.id');
	$platform = $bdd->query('SELECT *
		FROM platform INNER JOIN videogames ON platform.id=videogames.idPlatform
		ORDER BY videogames.id');
	$editeurs = $bdd->query('SELECT *
		FROM publishers INNER JOIN videogames ON publishers.id=videogames.idPublisher
		ORDER BY videogames.id');


// ===== Requête pour la recherche ===== //

	if (isset($_GET['search']) AND !empty($_GET['search'])) {
        $search = htmlspecialchars($_GET['search']);
        // $recherche = '"%".$search."%" ORDER BY Title';
        $videog = $bdd->query('SELECT * FROM developers INNER JOIN videogames ON developers.id=videogames.idDeveloper WHERE Title LIKE "%'.$search.'%" ORDER BY videogames.id '); 
        }

	if ($videog -> rowCount() > 0) {

// ================= Boucle While pour récupérer les éléments de la BDD ================ //
	while ($donnees = $videog->fetch()) 
	{	$platforme = $platform->fetch();
	$edits = $editeurs->fetch(); 
?>
<!-- ===== C'est ici que seront stocker les éléments de la BDD dans le tableau. En faisant appel à une boucle While ===== -->

			<tr>
				<td><p><?=$donnees['id']?></p></td>
				<td><p><?=$donnees['Title']?></p></td>
				<td class="release"><p><?=$donnees['ReleaseDate']?></p></td>
				<td><p><?=$platforme['name']?></p></td>
				<td class="publishers"><p><?=$edits['name']?></p></td>
				<td class="developers"><p><?=$donnees['name']?></p></td>
			</tr>

<?php
	}
						// Fin de la boucle. //
} 		
// Message affiché si la recherche n'aboutit pas.
else { echo '<p id="noresult">' .'Aucun résultat pour: "' .$search .'"' .'</p>';}
					//Termine le traitement de la requête//
$videog->closeCursor(); 

?>
		</table>
	</content>
	
	<footer>
		<p>Réalisé par Palumbo Thomas.</p>
		<a href="#top" class="tothetop"><i class="fas fa-arrow-alt-circle-up"></i></a>
		<a href="http://localhost/ProjetPHP/index.php"><i class="fas fa-home"></i>Return to complete list</a>
	</footer>
</body>
</html>

